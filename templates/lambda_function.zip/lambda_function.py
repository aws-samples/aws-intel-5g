import json
import os
import uuid
import ipaddress

import boto3
import requests

ec2 = boto3.client('ec2')


def get_route_table_id(event):
    subnet_id = event['ResourceProperties']['SubnetID']
    response = ec2.describe_route_tables(
        Filters=[
            {
                'Name': 'association.subnet-id',
                'Values': [subnet_id]
            }])
    if response.get('RouteTables'):
        route_table_id = response['RouteTables'][0]['Associations'][0]['RouteTableId']
    else:
        route_table_id = ''
    return route_table_id


def get_supernet_ip_cidr(event):
    ip_cidr = event['ResourceProperties']['VPCCIDR']
    try:
        ip_net = ipaddress.ip_network(ip_cidr)
        supernet_ip_cidr = ip_net.supernet(new_prefix=8)
    except ValueError:
        supernet_ip_cidr = ''
    return str(supernet_ip_cidr)


def send_response(event, result, data={}, reason=None, physical_resource_id=None):
    if result not in ['SUCCESS', 'FAILED']:
        raise Exception("Result is not a valid result")

    response = {'Status': result,
                'StackId': event['StackId'],
                'RequestId': event['RequestId'],
                'LogicalResourceId': event['LogicalResourceId'],
                'Data': data}

    if reason:
        response['Reason'] = reason
    if physical_resource_id:
        response['PhysicalResourceId'] = physical_resource_id
    else:
        response['PhysicalResourceId'] = uuid.uuid4().hex

    json_object = json.dumps(response)

    headers = {
        'content-type': '',
        'content-length': str(len(json_object))
    }

    print(json_object)
    requests.put(event['ResponseURL'], data=json_object, headers=headers)


def lambda_handler(event, context):
    print(json.dumps(event))
    print('## ENVIRONMENT VARIABLES')
    print(os.environ)
    print('## EVENT')
    print(event)
    data = {}
    # physical_resource_id = context['logStreamName']
    try:
        if event['RequestType'] == 'Create':
            route_table_id = get_route_table_id(event)
            if route_table_id:
                data['RouteTableId'] = route_table_id
                send_response(event, 'SUCCESS', data=data)
            else:
                send_response(event, 'FAILED')
        elif event['RequestType'] == 'Delete':
            send_response(event, 'SUCCESS')
        elif event['RequestType'] == 'Update':
            route_table_id = get_route_table_id(event)
            if route_table_id:
                data['RouteTableId'] = route_table_id
                send_response(event, 'SUCCESS', data=data)
            else:
                send_response(event, 'FAILED')
    except Exception as e:
        # Failure occurred
        # Sending an exception based response

        response = {
            'Status': 'FAILED',
            'Reason': str(e),
            'PhysicalResourceId': event.get('PhysicalResourceId', 'DoesNotMatter'),
            'StackId': event['StackId'],
            'RequestId': event['RequestId'],
            'LogicalResourceId': event['LogicalResourceId'],
            'Data': {}
        }

        json_object = json.dumps(response)

        headers = {
            'content-type': '',
            'content-length': str(len(json_object))
        }

        print(json_object)
        requests.put(event['ResponseURL'], data=json_object, headers=headers)


def handler_supernet_ip_cidr(event, context):
    print(json.dumps(event))
    print('## ENVIRONMENT VARIABLES')
    print(os.environ)
    print('## EVENT')
    print(event)
    data = {}
    # physical_resource_id = context['logStreamName']
    try:
        if event['RequestType'] == 'Create':
            supernet_ip_cidr = get_supernet_ip_cidr(event)
            if supernet_ip_cidr:
                data['SupernetCIDR'] = supernet_ip_cidr
                send_response(event, 'SUCCESS', data=data)
            else:
                send_response(event, 'FAILED')
        elif event['RequestType'] == 'Delete':
            send_response(event, 'SUCCESS')
        elif event['RequestType'] == 'Update':
            supernet_ip_cidr = get_supernet_ip_cidr(event)
            if supernet_ip_cidr:
                data['SupernetCIDR'] = supernet_ip_cidr
                send_response(event, 'SUCCESS', data=data)
            else:
                send_response(event, 'FAILED')
    except Exception as e:
        # Failure occurred
        # Sending an exception based response

        response = {
            'Status': 'FAILED',
            'Reason': str(e),
            'PhysicalResourceId': event.get('PhysicalResourceId', 'DoesNotMatter'),
            'StackId': event['StackId'],
            'RequestId': event['RequestId'],
            'LogicalResourceId': event['LogicalResourceId'],
            'Data': {}
        }

        json_object = json.dumps(response)

        headers = {
            'content-type': '',
            'content-length': str(len(json_object))
        }

        print(json_object)
        requests.put(event['ResponseURL'], data=json_object, headers=headers)
